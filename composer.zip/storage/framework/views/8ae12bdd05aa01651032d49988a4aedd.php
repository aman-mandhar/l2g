
<?php echo $__env->make('layouts.panels.vendor_panel.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h6>Stock Saved Successfully</h6>
            <table class="table">
                <tr>
                    <td><img src="<?php echo e(asset('storage/products/'.$product->prod_pic)); ?>" alt="Product Image Not Found" width="90px" height="90px"></td>
                    <td>
                        <label for="name">Product Name</label><br>
                        <?php echo e($product->name); ?>

                    </td>
                    <td>
                        <?php if($product->type == '1'): ?>
                            <label for="qty">Quantity</label><br>
                            <?php echo e($inventory->qty); ?>

                        <?php elseif($product->type == '2'): ?>
                            <label for="weight">Weight in kg.</label><br>
                            <?php echo e($inventory->weight); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <label for="cost_price">Cost Price</label><br>
                        <?php echo e($inventory->cost_price); ?>

                    </td>
                    <td>
                        <label for="mrp">MRP</label><br>
                        <?php echo e($inventory->mrp); ?>

                    </td>
                    <td>
                        <label for="sale_price">Sale Price</label><br>
                        <?php echo e($inventory->sale_price); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="batch_no">Batch No</label><br>
                        <?php echo e($inventory->batch_no); ?>

                    </td>
                    <td>
                        <label for="mfg_date">Manufacturing Date</label><br>
                        <?php echo e($inventory->mfg_date); ?>

                    </td>
                    <td>
                        <label for="exp_date">Expire Date</label><br>
                        <?php echo e($inventory->exp_date); ?>

                    </td>
                    <td>
                        <label for="remarks">Remarks</label><br>
                        <?php echo e($inventory->remarks); ?>

                    </td>
                </tr>
                <tr>
                    <td><label for="vendor_tokens">Vendor Tokens</label><br>
                        <?php echo e($inventory->vendor_tokens); ?>

                    </td>
                    <td><label for="vendor_ref_tokens">Vendor Referral Tokens</label><br>
                        <?php echo e($inventory->vendor_ref_tokens); ?>

                    </td>
                    <td><label for="customer_tokens">Customer Tokens</label><br>
                        <?php echo e($inventory->customer_tokens); ?>

                    </td>
                    <td><label for="ref_tokens">Customer Referral Tokens</label><br>
                        <?php echo e($inventory->ref_tokens); ?>

                    </td>
                    <td><label for="discount">Spl. Discount</label><br>
                        <?php echo e($inventory->discount); ?>

                    </td>
                </tr>
                <tr>
                    <td><label for="qr_code">QR Code</label><br>
                        <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG($inventory->qr_code, 'C39',1,33,array(1,1,1))); ?>" alt="barcode" />
                        <p>p - <?php echo e($inventory->qr_code); ?></p>
                    </td>
                    
            </table>
        </div>
        <div class="col-md-12">
            <a href="<?php echo e(route('inventories.addstock')); ?>" class="btn btn-primary">Add More Stock</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panels.vendor_panel.vendorlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ZK\laragon\www\L2G\resources\views/inventories/details.blade.php ENDPATH**/ ?>