
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-6">
            <p> 
                <h2><?php echo e($shop->shop_name); ?></h2>
                <h4><?php echo e($shop->add); ?></h4>
                <h4>Contact No. - <?php echo e($shop->mobile_no); ?></h4>
            </p>
        </div>
        <div class="col-md-6">
            <p>
                <h4>GST Number - <?php echo e($shop->gst_no); ?></h4>
            </p>
        </div>
    </div>
    <hr>

    <div class="row">
        <div class="col-md-12">
            <h4>Order Details</h4>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer Name</th>
                        <th>Customer Phone</th>
                        <th>Order Date</th>
                        <th>Billed by</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($customer->name); ?></td>
                        <td><?php echo e($customer->mobile_number); ?></td>
                        <td><?php echo e($order->created_at); ?></td>
                        <td><?php echo e($order->status); ?></td>
                    </tr>
                </tbody>
            </table>
            <hr>
            <table class="table table-bordered">
                <h4>Items in Order</h4>
                <thead>
                    <tr>
                        <th>Product Details</th>
                        <th>Qty. / Weight</th>
                        <th>Sale Price</th>
                        <th>Spl Discount</th>
                        <th>Sub-Total</th>
                    </tr>
                </thead>
                <tbody  class="col-md-12">
                    <?php if($orderItems): ?>
                        <?php $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($orderItem->product_name); ?> -
                                <?php echo e($orderItem->category); ?> -
                                <?php echo e($orderItem->subcategory); ?> -
                                <?php echo e($orderItem->color); ?> -
                                <?php echo e($orderItem->size); ?> -
                                <?php echo e($orderItem->weight); ?> -
                                <?php echo e($orderItem->length); ?> -
                                <?php echo e($orderItem->liquid_volume); ?>

                            </td>
                            <td>
                                <?php echo e($orderItem->quantity); ?>

                                <?php echo e($orderItem->item_weight); ?>

                            </td>
                            <td><?php echo e(number_format($orderItem->item_price. 2)); ?></td>
                            <td><?php echo e(number_format($orderItem->item_discount, 2)); ?></td>
                            <td><?php echo e(number_format($orderItem->item_total, 2)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <hr>
            <table class="table table-bordered">
                <h4>Order Summary</h4>
                <thead>
                    <tr>
                        <th>Discount</th>
                        <th>GST</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e(number_format($order->spl_discount, 2)); ?></td>
                        <td><?php echo e(number_format($order->gst, 2)); ?></td>
                        <td><?php echo e(number_format($amt_paid, 2)); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-12">
            <h4>Payment Details</h4>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Cash</th>
                        <th>Cheque</th>
                        <th>Upi</th>
                    </tr>
                </thead>
                <tbody>
                        <tr>
                            <td><?php echo e(number_format($order->cash, 2)); ?></td>
                            <td><?php echo e(number_format($order->card, 2)); ?></td>
                            <td><?php echo e(number_format($order->upi, 2)); ?></td>
                        </tr>
                </tbody>
            </table>
            <a href="<?php echo e(route('vendor_sales.usercheck')); ?>" class="btn btn-primary">New Sale</a>
            <button class="btn btn-primary" onclick="window.print()">Print</button>
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panels.vendor_panel.vendorlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ZK\laragon\www\L2G\resources\views/vendor_orders/show.blade.php ENDPATH**/ ?>