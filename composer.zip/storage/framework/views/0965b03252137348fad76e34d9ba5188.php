
<?php echo $__env->make('layouts.panels.admin_panel.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
New Admin Dashboard
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panels.admin_panel.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ZK\laragon\www\L2G\resources\views/layouts/panels/admin_panel/main.blade.php ENDPATH**/ ?>