
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Create New Sale for Customer</div>
                <div class="card-body">
                    <form method="get" action="<?php echo e(route('vendor_sales.check')); ?>">
                        <div class="form-group">
                            <label for="mobile_number">Mobile Number</label>
                            <input type="text" required class="form-control" id="mobile_number" name="mobile_number" placeholder="Enter Mobile Number" value="<?php echo e(old('mobile_number')); ?>">
                            <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <?php if($errors->any()): ?>
                            <script>
                                alert("Insert 10 digit mobile number only.");
                            </script>
                        <?php endif; ?>
                            <button type="submit" class="btn btn-primary">Check_In</button>
                    </form>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
        
    document.getElementById('ref_mobile_number').addEventListener('blur', function() {
            // Get the referral mobile number
            var referralMobileNumber = document.getElementById('ref_mobile_number').value;

            // Make an AJAX request to get the referral name
            fetch(`/getReferralName?referralMobileNumber=${referralMobileNumber}`)
                .then(response => response.json())
                .then(data => {
                    // Update the Referral Name field
                    document.getElementById('referral_name').innerText = data.name;
                })
                .catch(error => {
                    console.error('Error fetching Referral Name:', error);
                });
        });

// Function to update the email field based on mobile_number
function updateEmail() {
    var mobileNumberInput = document.getElementById('mobile_number');
    var emailInput = document.getElementById('email');

    if (mobileNumberInput && emailInput) {
        var mobileNumberValue = mobileNumberInput.value;
        var domain = '@zksuperstore.com';

        // Update the email input value
        emailInput.value = mobileNumberValue + domain;
    }
}

// Attach the event listener to the mobile_number input
document.getElementById('mobile_number').addEventListener('input', updateEmail);

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panels.admin_panel.vendorlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ZK\laragon\www\L2G\resources\views/admin_sales/usercheck.blade.php ENDPATH**/ ?>