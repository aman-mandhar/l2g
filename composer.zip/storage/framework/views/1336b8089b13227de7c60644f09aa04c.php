<?php $__env->startSection('content'); ?>
    <div class="container">
        <h5>Add New Subcategory</h5>
        <form action="<?php echo e(route('products.subcategories.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="category_id">Category</label>
                <select name="category_id" id="category_id" class="form-control">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="name">Subcategory Name:</label>
                <input type="text" name="name" id="name" class="form-control" placeholder="Enter Subcategory Name">
            </div>
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea name="description" id="description" class="form-control" placeholder="Enter Subcategory Description" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label for="image">Subcategory Image:</label>
                <input type="file" name="image" id="image" class="form-control-file">
            </div>
            <button type="submit" class="btn btn-primary">Add Subcategory</button>
        </form>

        <h5>All Subcategories</h5>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Subcategory Name</th>
                    <th>Category Name</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><img src="<?php echo e(asset('images/' .$subcategory->image)); ?>" alt="<?php echo e($subcategory->name); ?>" width="100"></td>
                        <td><?php echo e($subcategory->name); ?></td>
                        <td><?php echo e($subcategory->category->name); ?></td>
                        <td><?php echo e($subcategory->description); ?></td>
                        <td>
                            <form action="<?php echo e(route('products.subcategories.edit', $subcategory->id)); ?>" method="GET">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary">Edit</button>
                            </form>
                            <form action="<?php echo e(route('products.subcategories.destroy', $subcategory->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this subcategory?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3">No subcategories found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panels.vendor_panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ZK\laragon\www\L2G\resources\views/products/subcategories/create.blade.php ENDPATH**/ ?>