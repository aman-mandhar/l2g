<div class="midde_cont">
    <div class="container-fluid">
       <div class="row column_title">
          <div class="col-md-12">
             <div class="page_title">
                <h2>Dashboard</h2>
             </div>
          </div>
       </div>
      <!-- row -->
       <div class="col-md-6">
         <h4>Sale Report</h4>
      </div>
       <div class="row">
       <!-- table section -->
         
          <div class="col-md-6">
             <div class="white_shd full margin_bottom_30">
                <div class="full graph_head">
                   <div class="heading1 margin_0">
                      <h2>Vendor's Running Sale</h2>
                   </div>
                </div>
                <div class="table_section padding_infor_info">
                   <div class="table-responsive-sm">
                      <table class="table">
                         <thead>
                            <tr>
                               <th>Orders <br><?php echo e($today_orders); ?></th>
                               <th>Total <br><?php echo e($today_amount); ?> </th>
                               <th>Cash <br><?php echo e($today_cash); ?> </th>
                               <th>Card <br><?php echo e($today_card); ?> </th>
                               <th>Upi <br><?php echo e($today_upi); ?> </th>
                            </tr>
                         </thead>
                         <tbody>
                           <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                           <tr>
                              <td><?php echo e($order->id); ?></td>
                               <td><?php echo e($order->amount); ?></td>
                               <td><?php echo e($order->cash); ?></td>
                               <td><?php echo e($order->card); ?></td>
                               <td><?php echo e($order->upi); ?></td>
                            </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                         </tbody>
                      </table>
                   </div>
                </div>
             </div>
          </div>
          <!-- table section -->
          <div class="col-md-6">
            <div class="white_shd full margin_bottom_30">
               <div class="full graph_head">
                  <div class="heading1 margin_0">
                     <h2>Total Sale made by vendor</h2>
                  </div>
               </div>
               <div class="table_section padding_infor_info">
                  <div class="table-responsive-sm">
                     <table class="table">
                        <thead>
                           <tr>
                              <th>Orders <br><?php echo e($total_orders); ?></th>
                              <th>Total <br><?php echo e($total_amount); ?> </th>
                              <th>Cash <br><?php echo e($total_cash); ?> </th>
                              <th>Card <br><?php echo e($total_card); ?> </th>
                              <th>Upi <br><?php echo e($total_upi); ?> </th>
                           </tr>
                        </thead>
                        <tbody>
                          <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                          <tr>
                              <td><?php echo e($allProduct->id); ?></td>
                              <td><?php echo e($allProduct->amount); ?></td>
                              <td><?php echo e($allProduct->cash); ?></td>
                              <td><?php echo e($allProduct->card); ?></td>
                              <td><?php echo e($allProduct->upi); ?></td>
                           </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
         
          <div class="col-md-12">
             <div class="white_shd full margin_bottom_30">
                <div class="full graph_head">
                   <div class="heading1 margin_0">
                      <h2>Stock List</h2>
                   </div>
                </div>
                <div class="table_section padding_infor_info">
                   <div class="table-responsive-sm">
                      <table class="table">
                         <thead>
                            <tr>
                               <th>Name</th>
                               <th>Category</th>
                               <th>Sub-Category</th>
                               <th>Variations</th>
                               <th>Stock</th>
                               <th>MRP</th>
                               <th>Sale Price</th>
                            </tr>
                         </thead>
                         <tbody>
                           <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <tr>
                                 <td><?php echo e($stock->product_name); ?></td>
                                 <td><?php echo e($stock->category_name); ?></td>
                                 <td><?php echo e($stock->subcategory_name); ?></td>
                                 <td>
                                    <!--[if BLOCK]><![endif]--><?php if($stock->colour): ?>
                                       Colour - <?php echo e($stock->colour); ?>

                                    <?php elseif($stock->size): ?>
                                       Size - <?php echo e($stock->size); ?>

                                    <?php elseif($stock->weight): ?>
                                       Weight - <?php echo e($stock->weight); ?>

                                    <?php elseif($stock->length): ?>
                                       Length - <?php echo e($stock->length); ?>

                                    <?php elseif($stock->liquid): ?>
                                       Liquid - <?php echo e($stock->liquid); ?>

                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                 </td>
                                 <td>
                                    <!-- Stock in hand -->
                                    <?php
                                       $item = App\Models\Inventory::findOrFail($stock->id);
                                       $qty_in_stock = $item->qty;
                                       $weight_in_stock = $item->weight;
                                       $sold_qty = App\Models\VendCart::where('inventory_id', $stock->id)
                                                                        ->where('order_id', '!=', null)
                                                                        ->sum('quantity');
                                       $sold_weight = App\Models\VendCart::where('inventory_id', $stock->id)
                                                                        ->where('order_id', '!=', null)
                                                                        ->sum('weight');
                                       $qty = $qty_in_stock - $sold_qty;
                                       $weight = $weight_in_stock - $sold_weight;
                                    ?>

                                       <!--[if BLOCK]><![endif]--><?php if($stock->type == '1'): ?>
                                          <?php echo e($qty); ?>

                                       <?php else: ?>
                                          <?php echo e($weight); ?>

                                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                 </td>
                                 <td><?php echo e($stock->mrp); ?></td>
                                 <td><?php echo e($stock->price); ?></td>
                            </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                         </tbody>
                      </table>
                   </div>
                </div>
             </div>
          </div>
       </div>
    </div>
<?php /**PATH F:\ZK\laragon\www\L2G\resources\views/livewire/all-in-one.blade.php ENDPATH**/ ?>