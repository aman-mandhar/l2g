
<?php echo $__env->make('layouts.panels.vendor_panel.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
        
        <?php 
        $customer = session()->get('customer');
        $ref = session()->get('ref');
        $prod = session()->get('prods');
        ?>
       
        <table class="col-md-12">
            <tr>
                <td>CUSTOMER - <?php echo e($customer->name); ?> / Nob. No. <?php echo e($customer->mobile_number); ?></td>
            </tr>
            <tr>
                <td>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('vendor-shopping-cart');

$__html = app('livewire')->mount($__name, $__params, 'lw-1169527180-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </td>
            </tr>
        </table>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('vendor_sales.searchproduct')); ?>" method="GET">
                    <div class="form-group">
                        <label for="search">Search</label>
                        <input type="text" id="search" name="search" class="form-control" placeholder="Enter a keyword">
                        <button type="submit" class="btn btn-primary">Search</button>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="row">
            List of Stock
            <div class="col-md-12">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Stock in Hand</th>
                            <th>Sale Price</th>
                            <th>Quantity</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($prod->product_name); ?></td>
                            <td>
                                <?php
                                    $stock = App\Models\Inventory::findOrFail($prod->id);
                                    $qty_in_stock = $stock->qty;
                                    $weight_in_stock = $stock->weight;
                                    $sold_qty = App\Models\VendCart::where('inventory_id', $prod->id)
                                    ->where('order_id', '!=', null)
                                    ->sum('quantity');
                                    $sold_weight = App\Models\VendCart::where('inventory_id', $prod->id)
                                    ->where('order_id', '!=', null)
                                    ->sum('weight');
                                    $qty = $qty_in_stock - $sold_qty;
                                    $weight = $weight_in_stock - $sold_weight;
                                ?>
                                <?php if($prod->type == '1'): ?>
                                    <?php echo e($qty); ?>

                                <?php else: ?>
                                    <?php echo e($weight); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($prod->sale_price); ?>

                            </td>
                            <form action="<?php echo e(route('vendor_sales.addtocart')); ?>" method="POST">
                                <?php echo csrf_field(); ?> 
                            <td>   
                                <?php if($prod->type == '1'): ?>
                                    <input type="numeric" name="quantity" placeholder="Enter quantity">
                                <?php else: ?>
                                    <input type="numeric" name="weight" placeholder="Enter weight">
                                <?php endif; ?>
                            </td>
                            <td>
                                <input type="hidden" name="customer_id" value="<?php echo e($customer->id); ?>">
                                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                <input type="hidden" name="inventory_id" value="<?php echo e($prod->id); ?>">
                                <input type="hidden" name="product_name" value="<?php echo e($prod->product_name); ?>">
                                <input type="hidden" name="price" value="<?php echo e($prod->sale_price); ?>">
                                <input type="hidden" name="discount" value="<?php echo e($prod->discount); ?>">
                                <input type="hidden" name="gst_rate" value="<?php echo e($prod->gst_rate); ?>">
                                <button type="submit" class="btn btn-primary">Add to Cart</button>
                            </td>
                            </form>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>                
        </div>
    </div>    
</div>
   
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.panels.vendor_panel.vendorlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ZK\laragon\www\L2G\resources\views/vendor_sales/create.blade.php ENDPATH**/ ?>