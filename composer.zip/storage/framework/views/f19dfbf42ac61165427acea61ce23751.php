<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div x-data="{ open: false }">
                <button @click="open = !open">View Cart</button>
                <div x-show="open" @click.outside="open = false">
                    <div class="col-md-12">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Sale Price</th>
                                    <th>Qty. / Weight</th>
                                    <th>Spl Discount</th>
                                    <th>Sub-Total</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!--[if BLOCK]><![endif]--><?php if($carts->isEmpty()): ?>
                                <tr>
                                    <td colspan="6">No items in cart</td>
                                </tr>
                                <?php else: ?>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($cart->product_name); ?></td>
                                    <td><?php echo e($cart->price); ?></td>
                                    <td><?php echo e($cart->quantity); ?><?php echo e($cart->weight); ?></td>
                                    <td><?php echo e($cart->discount); ?></td>
                                    <td><?php echo e($cart->total); ?></td>
                                    <td>
                                        <button wire:click="removeFromCart(<?php echo e($cart->id); ?>)" class="btn btn-danger">Remove</button>
                                    </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </tr>
                                <tr>
                                    <td>
                                        <b>Total of Spl. Discount</b><br>
                                        <input type="text" wire:model="discount" class="form-control" value="<?php echo e($carts->sum('discount')); ?>" readonly>
                                    </td>
                                    <td>
                                        <b>Total Amount</b><br>
                                        <input type="text" wire:model="total" class="form-control" value="<?php echo e($carts->sum('total')); ?>" readonly>    
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="6">
                                        <a href="<?php echo e(route('vendor_sales.create')); ?>" class="btn btn-primary">Continue Shopping</a>
                                        <a href="<?php echo e(route('vendor_sales.checkout')); ?>" class="btn btn-success">Checkout</a>
                                    </td>
                                </tr>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH F:\ZK\laragon\www\L2G\resources\views/livewire/vendor-shopping-cart.blade.php ENDPATH**/ ?>