
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h1>Add Shop</h1>
            <form method="POST" action="<?php echo e(route('shops.create_new')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="mobile_number">Registered Mobile No.</label>
                    <input type="text" class="form-control" id="mobile_number" name="mobile_number">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panels.admin_panel.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ZK\laragon\www\L2G\resources\views/shops/create.blade.php ENDPATH**/ ?>