
<?php echo $__env->make('layouts.panels.vendor_panel.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<div class="col-md-9">
    <div class="white_shd full margin_bottom_30">
       <div class="full graph_head">
          <div class="heading1 margin_0">
             <h2>Bordered Table</h2>
          </div>
       </div>
       <div class="table_section padding_infor_info">
          <div class="table-responsive-sm">
             <table class="table table-bordered">
                <thead>
                   <tr>
                      <th>Product Name</th>
                        <th>Image</th>
                        <th>Category</th>
                        <th>GST Rate</th>
                        <th>Description</th>
                   </tr>
                </thead>
                <tbody>
                   <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                      <td><?php echo e($product->name); ?></td>
                      <td><img src="<?php echo e(asset('storage/'.$product->product_image)); ?>" alt="product image" style="width: 50px; height: 50px;"></td>
                      <td><?php echo e($product->category->name); ?></td>
                      <td><?php echo e($product->gst); ?></td>
                      <td><?php echo e($product->description); ?></td>
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panels.vendor_panel.vendorlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ZK\laragon\www\L2G\resources\views/vendor_products/index.blade.php ENDPATH**/ ?>