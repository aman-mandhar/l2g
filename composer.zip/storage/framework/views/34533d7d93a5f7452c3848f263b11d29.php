<?php $__env->startSection('content'); ?>
    <div class="container">
        <h5>Add New Variation</h5>
        <form action="<?php echo e(route('products.variations.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="subcategory_id">Subcategory</label>
                <select name="subcategory_id" id="subcategory_id" class="form-control">
                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subcategory->id); ?>"><?php echo e($subcategory->category->name); ?> / <?php echo e($subcategory->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="color">Color</label>
                <input type="text" name="color" id="color" class="form-control">
            </div>
            <div class="form-group">
                <label for="size">Size</label>
                <input type="text" name="size" id="size" class="form-control">
            </div>
            <div class="form-group">
                <label for = "weight">Weight</label>
                <input type="text" name="weight" id="weight" class="form-control">
            </div>
            <div class="form-group">
                <label for = "length">Length</label>
                <input type="text" name="length" id="length" class="form-control">
            </div>
            <div class="form-group">
                <label for = "liquid_volume">Liquid Volume</label>
                <input type="liquid_volume" name="liquid_volume" id="liquid_volume" class="form-control">
            </div>              
            <button type="submit" class="btn btn-primary">Add Variation</button>
        </form>

        <h5>All Variations</h5>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Category</th>
                    <th>Subcategory</th>
                    <th>Colour</th>
                    <th>Size</th>
                    <th>Weight</th>
                    <th>Length</th>
                    <th>Liquid Volume</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($variation->subcategory->category->name); ?></td>
                        <td><?php echo e($variation->subcategory->name); ?></td>
                        <td><?php echo e($variation->color); ?></td>
                        <td><?php echo e($variation->size); ?></td>
                        <td><?php echo e($variation->weight); ?></td>
                        <td><?php echo e($variation->length); ?></td>
                        <td><?php echo e($variation->liquid_volume); ?></td>
                        <td>
                            <a href="<?php echo e(route('products.variations.edit', $variation->id)); ?>" class="btn btn-primary">Edit</a>
                        </td>
                        <td>
                            <form action="<?php echo e(route('products.variations.destroy', $variation->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this variation?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5">No variations found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panels.vendor_panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ZK\laragon\www\L2G\resources\views/products/variations/create.blade.php ENDPATH**/ ?>