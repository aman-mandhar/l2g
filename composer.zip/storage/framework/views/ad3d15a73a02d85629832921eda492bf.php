<div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="col-md-12">
                    <h4>Customer Details</h4>
                    <tr>
                        <td>CUSTOMER - <?php echo e($customer->name); ?> / Mob. No. <?php echo e($customer->mobile_number); ?></td>
                    </tr>
                </table>
                <hr>
                <table>
                    <h4>Items in Cart</h4>
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Qty. / Weight</th>
                            <th>Sale Price</th>
                            <th>Spl Discount</th>
                            <th>GST</th>
                            <th>Sub-Total</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody  class="col-md-12">
                        
                        <!--[if BLOCK]><![endif]--><?php if($carts): ?>
                            
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($cart->product_name); ?></td>
                                <td><?php echo e($cart->quantity); ?><?php echo e($cart->weight); ?></td>
                                <td><?php echo e($cart->price); ?></td>
                                <td><?php echo e($cart->discount); ?></td>
                                <td><?php echo e(number_format($cart->total_gst, 2)); ?></td>
                                <td><?php echo e($cart->total); ?></td>
                                <td>
                                    <button wire:click="removeFromCart(<?php echo e($cart->id); ?>)" class="btn btn-danger">Remove</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php else: ?>
                            <tr>
                                <td colspan="9">No Items in Cart</td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <tr>
                            <td>
                                <b>Total GST</b><br>
                                <?php echo e($total_gst); ?>

                            </td>
                            <td>
                                <b>Total Amount</b><br>
                                <?php echo e($total_amount); ?>    
                            </td>
                            <td>
                                <b>Amount Payable</b><br>
                                <?php echo e(ceil($amt_payable)); ?>

                            </td>
                            <td>
                                <div class="form-group">
                                    <b>Spl. discount applying : <?php echo e($total_discount); ?></b><br>
                                </div>
                            </td>
                        </tr>
                        <form wire:submit.prevent="savePayment">
                        <tr>
                            <td>
                                Cash<br>
                                <input type="number" wire:model.lazy="cash" class="form-control" step="0.01">        
                            </td>
                            <td>
                                Card<br>
                                <input type="number" wire:model.lazy="card" class="form-control" step="0.01">
                            </td>
                            <td>
                                UPI<br>
                                <input type="number" wire:model.lazy="upi" class="form-control" step="0.01">
                            </td>
                            <td>
                                <b>More to Pay : <?php echo e($amt_payable); ?></b>
                            </td>
                            <td>
                                <button type="submit" class="btn btn-primary">Save Payment</button>
                            </td>
                        </tr>
                        </form>
                    </tbody>
                </table>
                <div">
                    <a href="<?php echo e(route('vendor_sales.create')); ?>" class="btn btn-primary">Add more Items</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH F:\ZK\laragon\www\L2G\resources\views/livewire/vendor-checkout.blade.php ENDPATH**/ ?>