
<?php echo $__env->make('layouts.panels.vendor_panel.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <table class="table table-striped">
        <h4>Sale Orders List</h4>
        <tr>
            <th>Order ID</th>
            <th>Product Name</th>
            <th>Discount Coupens</th>
            <th>Amount</th>
            <th>GST</th>
            <th>Date</th>
            <th>Action</th>
            
        </tr>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order->id); ?></td>
                <td><?php echo e($order->product_name); ?></td>
                <td><?php echo e($order->order_discount); ?></td>
                <td><?php echo e($order->amount); ?></td>
                <td><?php echo e($order->gst); ?></td>
                <td><?php echo e($order->created_at); ?></td>
                <td><a href="<?php echo e(route('vendor_orders.show', $order->id)); ?>">View</a></td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panels.vendor_panel.vendorlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ZK\laragon\www\L2G\resources\views/vendor_orders/index.blade.php ENDPATH**/ ?>