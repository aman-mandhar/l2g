
<?php echo $__env->make('layouts.panels.admin_panel.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1>Vendors</h1>
            <a href="<?php echo e(route('vendors.create')); ?>" class="btn btn-primary">Add Vendor</a>
            <table class="table">
                <thead>
                    <tr>
                        <th>Vendor Name</th>
                        <th>Vendor Address</th>
                        <th>Vendor City</th>
                        <th>Vendor Phone</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($vendor->vendor_name); ?></td>
                        <td><?php echo e($vendor->add); ?></td>
                        <td><?php echo e($vendor->city); ?></td>
                        <td><?php echo e($vendor->mobile_no); ?></td>
                        <td>
                            <a href="<?php echo e(route('vendors.edit', $vendor->id)); ?>" class="btn btn-warning">Edit</a>
                            <form style="display:inline-block" method="POST" action="<?php echo e(route('vendors.destroy', $vendor->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.panels.admin_panel.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ZK\laragon\www\L2G\resources\views/vendors/index.blade.php ENDPATH**/ ?>