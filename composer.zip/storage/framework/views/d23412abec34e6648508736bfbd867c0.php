
<?php echo $__env->make('layouts.panels.admin_panel.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h1>Add Vendor</h1>
            <form method="POST" action="<?php echo e(route('vendors.store')); ?>">
                <?php echo method_field('POST'); ?>
                <?php echo csrf_field(); ?>
                User Name : <?php echo e($user->name); ?><br>
                
                <div class="form-group">
                    <label for="vendor_name">Vendor Name</label>
                    <input type="text" class="form-control" id="vendor_name" name="vendor_name">
                </div>
                <div class="form-group">
                    <label for="add">Vendor Address</label>
                    <input type="text" class="form-control" id="add" name="add">
                </div>
                <div class="form-group">
                    <label for="email">Vendor Email</label>
                    <input type="email" class="form-control" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="mobile_no">Vendor Phone</label>
                    <input type="text" class="form-control" id="mobile_no" name="mobile_no">
                </div>
                <div class="form-group">
                    <label for="mobile_no">GST No.</label>
                    <input type="text" class="form-control" id="gst_no" name="gst_no">
                </div>
                <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Add Vendor</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panels.admin_panel.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ZK\laragon\www\L2G\resources\views/vendors/create-new.blade.php ENDPATH**/ ?>