
<?php echo $__env->make('layouts.panels.vendor_panel.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Inventory</h1>
                <a href="<?php echo e(route('inventories.create')); ?>" class="btn btn-primary">Add Inventory</a>
                <form action="<?php echo e(route('inventories.search')); ?>" method="GET">
                    <div class="form-group">
                        <label for="search">Search</label>
                        <input type="text" id="search" name="search" class="form-control" placeholder="Enter a keyword">
                        <button type="submit" class="btn btn-primary">Search</button>
                    </div>
                </form>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Product Price</th>
                            <th>Stock in Hand</th>
                            <th>Barcode</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($inventory->product_name); ?></td>
                                <td><?php echo e($inventory->sale_price); ?></td>
                                <td>
                                    <!-- Fetching Balance Stock -->
                                    <?php
                                    $stock = App\Models\Inventory::findOrFail($inventory->id);
                                    $qty_in_stock = $stock->qty;
                                    $weight_in_stock = $stock->weight;
                                    $sold_qty = App\Models\VendCart::where('inventory_id', $inventory->id)
                                    ->where('order_id', '!=', null)
                                    ->sum('quantity');
                                    $sold_weight = App\Models\VendCart::where('inventory_id', $inventory->id)
                                    ->where('order_id', '!=', null)
                                    ->sum('weight');
                                    $qty = $qty_in_stock - $sold_qty;
                                    $weight = $weight_in_stock - $sold_weight;
                                ?>
                                <?php if($inventory->product_type == '1'): ?>
                                    <?php echo e($qty); ?>

                                <?php else: ?>
                                    <?php echo e($weight); ?>

                                <?php endif; ?>

                                </td>
                                <td>
                                    <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG($inventory->qr_code, 'C39',1,33,array(1,1,1))); ?>" alt="barcode" />
                                    <p>p - <?php echo e($inventory->qr_code); ?></p>
                                </td>
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <button type="button" class="btn btn-primary" onclick="window.print()">Print</button>     
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panels.vendor_panel.vendorlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ZK\laragon\www\L2G\resources\views/inventories/index.blade.php ENDPATH**/ ?>