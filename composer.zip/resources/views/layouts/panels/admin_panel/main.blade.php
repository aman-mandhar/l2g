@extends('layouts.panels.admin_panel.dashboard')
@include('layouts.panels.admin_panel.navbar')
@section('content')
New Admin Dashboard
@endsection