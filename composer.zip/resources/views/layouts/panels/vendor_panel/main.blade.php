@extends('layouts.panels.vendor_panel.vendorlayout')
@section('content')
<!-- Vendor Dashboard -->
@livewire('all-in-one')
                    
@endsection