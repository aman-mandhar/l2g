<div class="footer_section layout_padding">
   <div class="container">
      <div class="row">
      
        <div class="col-lg-3 col-sm-3">
         <div class="information_main">
         <h5 class="information_text">Get to Know Us</h5>
        <p class="call_text"><a href="#">About us</a></p>
        <p class="call_text"><a href="#">Careers</a></p>
        <p class="call_text"><a href="#">Press Release</a></p>
        <p class="call_text"><a href="#">Contact us</a></p>
         </div>
        </div>       
      
        <div class="col-lg-3 col-sm-3">
             <div class="information_main">
         <h5 class="information_text">Sale Points</h5>
        <p class="call_text"><a href="#">Super Stores</a></p>
        <p class="call_text"><a href="#">Shops</a></p>
        <p class="call_text"><a href="#">Service Partners</a></p>
      </div>
   </div>
      
        <div class="col-lg-3 col-sm-3">
             <div class="information_main">
         <h5 class="information_text">Make Money with Us</h5>
        <p class="call_text"><a href="#">Sell on ZK</a></p>
        <p class="call_text"><a href="#">Sell under ZK</a></p>
        <p class="call_text"><a href="#">Become an Associate</a></p>
      </div>
   </div>
      
        <div class="col-lg-3 col-sm-3">
             <div class="information_main">
         <h5 class="information_text">Let Us Help You</h5>
        <p class="call_text"><a href="#">List of Frenchises</a></p>
        <p class="call_text"><a href="#">Your Account</a></p>
        <p class="call_text"><a href="#">Return Centre</a></p>
        <p class="call_text"><a href="#">100% Purchase Protection</a></p>
        <p class="call_text"><a href="#">App Download</a></p>
        <p class="call_text"><a href="#">Help</a></p>
      </div>
   </div>
      </ul>
      </div>
   </div>
</div>
  
<div class="footer_section layout_padding">
    <div class="container">
       <div class="row">
          <div class="col-lg-6 col-sm-12">
             <h4 class="information_text">Category</h4>
             <p class="dummy_text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim </p>
          </div>
          <div class="col-lg-3 col-sm-6">
             <div class="information_main">
                <h4 class="information_text">Useful Links</h4>
                <p class="many_text">Contrary to popular belief, Lorem Ipsum is not simply random text. It </p>
             </div>
          </div>
          <div class="col-lg-3 col-sm-6">
             <div class="information_main">
                <h4 class="information_text">Contact Us</h4>
                <p class="call_text"><a href="#">+01 8283847501</a></p>
                <p class="call_text"><a href="#">contact@zksuperstore.com</a></p>
                <div class="social_icon">
                   <ul>
                      <li><a href="#"><img src="{{ asset('ecom/images/fb-icon.png') }}"></a></li>
                      <li><a href="#"><img src="{{ asset('ecom/images/twitter-icon.png') }}"></a></li>
                      <li><a href="#"><img src="{{ asset('ecom/images/linkedin-icon.png') }}"></a></li>
                      <li><a href="#"><img src="{{ asset('ecom/images/instagram-icon.png') }}"></a></li>
                   </ul>
                </div>
             </div>
          </div>
       </div>
       <div class="copyright_section">
          <h1 class="copyright_text">
          Copyright 2024 All Right Reserved <a href="https://zksuperstore.com"> ZED KAY SUPERSTORE </a><br>
          Developed by <a href="https://parthmultisolutions.com"> Parth Multisolutions </a>
       </div>
    </div>
 </div>
 <!-- footer section end -->
 