@extends('layouts.panels.vendor_panel.vendorlayout')
@include('layouts.panels.vendor_panel.navbar')
@section('content')
Show
@endsection