@extends('layouts.admin')
@section('content')
Store Dashboard
@endsection