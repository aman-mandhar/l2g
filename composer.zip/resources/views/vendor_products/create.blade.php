@extends('layouts.panels.vendor_panel.vendorlayout')
@include('layouts.panels.vendor_panel.navbar')
@section('content')

@livewire('VendorProduct')

@endsection