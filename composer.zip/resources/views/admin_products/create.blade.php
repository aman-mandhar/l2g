@extends('layouts.panels.admin_panel.dashboard')
@section('content')

@livewire('VendorProduct')

@endsection