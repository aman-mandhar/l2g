@extends('layouts.panels.admin_panel.vendorlayout')
@section('content')

@livewire('vendor-checkout')

@endsection