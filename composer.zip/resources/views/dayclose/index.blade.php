@extends('layouts.panels.admin_panel.dashboard')
@section('content')

@livewire('DayClose')




@endsection