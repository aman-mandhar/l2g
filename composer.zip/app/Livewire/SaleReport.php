<?php

namespace App\Livewire;

use Livewire\Component;

class SaleReport extends Component
{
    public function render()
    {
        return view('livewire.sale-report');
    }
}
